KangoAPI.onReady(function() {

});
